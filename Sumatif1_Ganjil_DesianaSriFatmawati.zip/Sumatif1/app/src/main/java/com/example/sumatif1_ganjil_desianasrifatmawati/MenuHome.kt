package com.example.sumatif1_ganjil_desianasrifatmawati

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MenuHome : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menu_home)
    }
}