package com.example.sumatif1_ganjil_desianasrifatmawati

data class DataGambar (val gambar : Int , val jurusan :String , val nama_jurusan: String)
